﻿using System;
using System.Windows.Forms;

namespace jeu_memory
{
    class Effet
    {
        public void attente(long millisec_a_attendre)
        {
            double Fin_Attente;
            Fin_Attente = Environment.TickCount + millisec_a_attendre;
            while (Environment.TickCount < Fin_Attente)
            {
                System.Threading.Thread.Sleep(1);
                Application.DoEvents();
            }
        }
        public void effet_qui_bouge(int lignePremier, int colonnePremier, int ligneDeuxieme, int colonneDeuxieme, PictureBox[,] tableauPictureBox)
        {
            int Grosseur;
            Grosseur = 5;
            for (int cpt = 0; cpt <= 5; cpt++)
            {
                tableauPictureBox[lignePremier, colonnePremier].Height = tableauPictureBox[lignePremier, colonnePremier].Height + Grosseur;
                tableauPictureBox[lignePremier, colonnePremier].Width = tableauPictureBox[lignePremier, colonnePremier].Width + Grosseur;
                tableauPictureBox[ligneDeuxieme, colonneDeuxieme].Height = tableauPictureBox[ligneDeuxieme, colonneDeuxieme].Height + Grosseur;
                tableauPictureBox[ligneDeuxieme, colonneDeuxieme].Width = tableauPictureBox[ligneDeuxieme, colonneDeuxieme].Width + Grosseur;
                attente(100);
                Grosseur = -Grosseur;
            }
        }
    }
}
