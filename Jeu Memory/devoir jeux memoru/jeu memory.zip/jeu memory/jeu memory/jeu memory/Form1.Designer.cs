﻿
namespace jeu_memory
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.picboxl0e0 = new System.Windows.Forms.PictureBox();
            this.picboxl2e2 = new System.Windows.Forms.PictureBox();
            this.picboxl3e1 = new System.Windows.Forms.PictureBox();
            this.picboxl3e0 = new System.Windows.Forms.PictureBox();
            this.picboxl3e2 = new System.Windows.Forms.PictureBox();
            this.picboxl2e3 = new System.Windows.Forms.PictureBox();
            this.picboxl2e1 = new System.Windows.Forms.PictureBox();
            this.picboxl2e0 = new System.Windows.Forms.PictureBox();
            this.picboxl1e0 = new System.Windows.Forms.PictureBox();
            this.picboxl1e1 = new System.Windows.Forms.PictureBox();
            this.picboxl1e2 = new System.Windows.Forms.PictureBox();
            this.picboxl1e3 = new System.Windows.Forms.PictureBox();
            this.picboxl0e3 = new System.Windows.Forms.PictureBox();
            this.picboxl0e2 = new System.Windows.Forms.PictureBox();
            this.picboxl0e1 = new System.Windows.Forms.PictureBox();
            this.picboxl3e3 = new System.Windows.Forms.PictureBox();
            this.btnStartChrono = new System.Windows.Forms.Button();
            this.lblTimer = new System.Windows.Forms.Label();
            this.lblNumberOfTry = new System.Windows.Forms.Label();
            this.txtTimer = new System.Windows.Forms.TextBox();
            this.txtNumberOfTry = new System.Windows.Forms.TextBox();
            this.Chrono = new System.Windows.Forms.Timer(this.components);
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.lblBesttime = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblDisplayClickNumber = new System.Windows.Forms.Label();
            this.txtClickNumberToDisplay = new System.Windows.Forms.TextBox();
            this.mnstripDifficulty = new System.Windows.Forms.MenuStrip();
            this.difficultyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnstripchoiceIntermediaire = new System.Windows.Forms.ToolStripMenuItem();
            this.mnstripchoiceDifficile = new System.Windows.Forms.ToolStripMenuItem();
            this.errorProviderbtnStart = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.picboxl0e0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl2e2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl3e1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl3e0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl3e2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl2e3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl2e1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl2e0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl1e0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl1e1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl1e2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl1e3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl0e3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl0e2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl0e1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl3e3)).BeginInit();
            this.mnstripDifficulty.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderbtnStart)).BeginInit();
            this.SuspendLayout();
            // 
            // picboxl0e0
            // 
            this.picboxl0e0.Location = new System.Drawing.Point(81, 78);
            this.picboxl0e0.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl0e0.Name = "picboxl0e0";
            this.picboxl0e0.Size = new System.Drawing.Size(133, 86);
            this.picboxl0e0.TabIndex = 0;
            this.picboxl0e0.TabStop = false;
            this.picboxl0e0.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // picboxl2e2
            // 
            this.picboxl2e2.Location = new System.Drawing.Point(405, 266);
            this.picboxl2e2.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl2e2.Name = "picboxl2e2";
            this.picboxl2e2.Size = new System.Drawing.Size(133, 89);
            this.picboxl2e2.TabIndex = 1;
            this.picboxl2e2.TabStop = false;
            this.picboxl2e2.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // picboxl3e1
            // 
            this.picboxl3e1.Location = new System.Drawing.Point(243, 362);
            this.picboxl3e1.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl3e1.Name = "picboxl3e1";
            this.picboxl3e1.Size = new System.Drawing.Size(133, 80);
            this.picboxl3e1.TabIndex = 2;
            this.picboxl3e1.TabStop = false;
            this.picboxl3e1.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // picboxl3e0
            // 
            this.picboxl3e0.Location = new System.Drawing.Point(81, 362);
            this.picboxl3e0.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl3e0.Name = "picboxl3e0";
            this.picboxl3e0.Size = new System.Drawing.Size(133, 80);
            this.picboxl3e0.TabIndex = 3;
            this.picboxl3e0.TabStop = false;
            this.picboxl3e0.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // picboxl3e2
            // 
            this.picboxl3e2.Location = new System.Drawing.Point(405, 362);
            this.picboxl3e2.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl3e2.Name = "picboxl3e2";
            this.picboxl3e2.Size = new System.Drawing.Size(133, 80);
            this.picboxl3e2.TabIndex = 4;
            this.picboxl3e2.TabStop = false;
            this.picboxl3e2.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // picboxl2e3
            // 
            this.picboxl2e3.Location = new System.Drawing.Point(564, 266);
            this.picboxl2e3.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl2e3.Name = "picboxl2e3";
            this.picboxl2e3.Size = new System.Drawing.Size(133, 89);
            this.picboxl2e3.TabIndex = 5;
            this.picboxl2e3.TabStop = false;
            this.picboxl2e3.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // picboxl2e1
            // 
            this.picboxl2e1.Location = new System.Drawing.Point(243, 266);
            this.picboxl2e1.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl2e1.Name = "picboxl2e1";
            this.picboxl2e1.Size = new System.Drawing.Size(133, 89);
            this.picboxl2e1.TabIndex = 6;
            this.picboxl2e1.TabStop = false;
            this.picboxl2e1.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // picboxl2e0
            // 
            this.picboxl2e0.Location = new System.Drawing.Point(81, 266);
            this.picboxl2e0.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl2e0.Name = "picboxl2e0";
            this.picboxl2e0.Size = new System.Drawing.Size(133, 89);
            this.picboxl2e0.TabIndex = 7;
            this.picboxl2e0.TabStop = false;
            this.picboxl2e0.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // picboxl1e0
            // 
            this.picboxl1e0.Location = new System.Drawing.Point(81, 171);
            this.picboxl1e0.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl1e0.Name = "picboxl1e0";
            this.picboxl1e0.Size = new System.Drawing.Size(133, 87);
            this.picboxl1e0.TabIndex = 8;
            this.picboxl1e0.TabStop = false;
            this.picboxl1e0.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // picboxl1e1
            // 
            this.picboxl1e1.Location = new System.Drawing.Point(243, 171);
            this.picboxl1e1.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl1e1.Name = "picboxl1e1";
            this.picboxl1e1.Size = new System.Drawing.Size(133, 87);
            this.picboxl1e1.TabIndex = 9;
            this.picboxl1e1.TabStop = false;
            this.picboxl1e1.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // picboxl1e2
            // 
            this.picboxl1e2.Location = new System.Drawing.Point(405, 171);
            this.picboxl1e2.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl1e2.Name = "picboxl1e2";
            this.picboxl1e2.Size = new System.Drawing.Size(133, 87);
            this.picboxl1e2.TabIndex = 10;
            this.picboxl1e2.TabStop = false;
            this.picboxl1e2.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // picboxl1e3
            // 
            this.picboxl1e3.Location = new System.Drawing.Point(564, 171);
            this.picboxl1e3.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl1e3.Name = "picboxl1e3";
            this.picboxl1e3.Size = new System.Drawing.Size(133, 87);
            this.picboxl1e3.TabIndex = 11;
            this.picboxl1e3.TabStop = false;
            this.picboxl1e3.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // picboxl0e3
            // 
            this.picboxl0e3.Location = new System.Drawing.Point(564, 78);
            this.picboxl0e3.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl0e3.Name = "picboxl0e3";
            this.picboxl0e3.Size = new System.Drawing.Size(133, 86);
            this.picboxl0e3.TabIndex = 12;
            this.picboxl0e3.TabStop = false;
            this.picboxl0e3.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // picboxl0e2
            // 
            this.picboxl0e2.Location = new System.Drawing.Point(405, 78);
            this.picboxl0e2.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl0e2.Name = "picboxl0e2";
            this.picboxl0e2.Size = new System.Drawing.Size(133, 86);
            this.picboxl0e2.TabIndex = 13;
            this.picboxl0e2.TabStop = false;
            this.picboxl0e2.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // picboxl0e1
            // 
            this.picboxl0e1.Location = new System.Drawing.Point(243, 78);
            this.picboxl0e1.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl0e1.Name = "picboxl0e1";
            this.picboxl0e1.Size = new System.Drawing.Size(133, 86);
            this.picboxl0e1.TabIndex = 14;
            this.picboxl0e1.TabStop = false;
            this.picboxl0e1.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // picboxl3e3
            // 
            this.picboxl3e3.Location = new System.Drawing.Point(564, 362);
            this.picboxl3e3.Margin = new System.Windows.Forms.Padding(4);
            this.picboxl3e3.Name = "picboxl3e3";
            this.picboxl3e3.Size = new System.Drawing.Size(133, 80);
            this.picboxl3e3.TabIndex = 15;
            this.picboxl3e3.TabStop = false;
            this.picboxl3e3.Click += new System.EventHandler(this.Picboxl1e1_Click);
            // 
            // btnStartChrono
            // 
            this.btnStartChrono.Enabled = false;
            this.btnStartChrono.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnStartChrono.Location = new System.Drawing.Point(824, 46);
            this.btnStartChrono.Margin = new System.Windows.Forms.Padding(4);
            this.btnStartChrono.Name = "btnStartChrono";
            this.btnStartChrono.Size = new System.Drawing.Size(161, 39);
            this.btnStartChrono.TabIndex = 16;
            this.btnStartChrono.Text = "Start";
            this.btnStartChrono.UseVisualStyleBackColor = true;
            this.btnStartChrono.Click += new System.EventHandler(this.BtnStartChrono_Click);
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.Location = new System.Drawing.Point(876, 142);
            this.lblTimer.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(52, 17);
            this.lblTimer.TabIndex = 17;
            this.lblTimer.Text = "Timer :";
            // 
            // lblNumberOfTry
            // 
            this.lblNumberOfTry.AutoSize = true;
            this.lblNumberOfTry.Location = new System.Drawing.Point(821, 193);
            this.lblNumberOfTry.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumberOfTry.Name = "lblNumberOfTry";
            this.lblNumberOfTry.Size = new System.Drawing.Size(107, 17);
            this.lblNumberOfTry.TabIndex = 18;
            this.lblNumberOfTry.Text = "Number of Try :";
            // 
            // txtTimer
            // 
            this.txtTimer.Enabled = false;
            this.txtTimer.Location = new System.Drawing.Point(948, 142);
            this.txtTimer.Name = "txtTimer";
            this.txtTimer.ReadOnly = true;
            this.txtTimer.Size = new System.Drawing.Size(101, 22);
            this.txtTimer.TabIndex = 19;
            this.txtTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtNumberOfTry
            // 
            this.txtNumberOfTry.Enabled = false;
            this.txtNumberOfTry.Location = new System.Drawing.Point(949, 193);
            this.txtNumberOfTry.Name = "txtNumberOfTry";
            this.txtNumberOfTry.ReadOnly = true;
            this.txtNumberOfTry.Size = new System.Drawing.Size(101, 22);
            this.txtNumberOfTry.TabIndex = 20;
            // 
            // Chrono
            // 
            this.Chrono.Interval = 1000;
            this.Chrono.Tick += new System.EventHandler(this.Chrono_Tick);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(266, 482);
            this.progressBar1.MarqueeAnimationSpeed = 1000;
            this.progressBar1.Maximum = 16;
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(253, 23);
            this.progressBar1.Step = 0;
            this.progressBar1.TabIndex = 23;
            // 
            // lblBesttime
            // 
            this.lblBesttime.AutoSize = true;
            this.lblBesttime.Location = new System.Drawing.Point(850, 292);
            this.lblBesttime.Name = "lblBesttime";
            this.lblBesttime.Size = new System.Drawing.Size(78, 17);
            this.lblBesttime.TabIndex = 22;
            this.lblBesttime.Text = "Best time : ";
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(949, 289);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 21;
            // 
            // lblDisplayClickNumber
            // 
            this.lblDisplayClickNumber.AutoSize = true;
            this.lblDisplayClickNumber.Location = new System.Drawing.Point(820, 347);
            this.lblDisplayClickNumber.Name = "lblDisplayClickNumber";
            this.lblDisplayClickNumber.Size = new System.Drawing.Size(108, 17);
            this.lblDisplayClickNumber.TabIndex = 25;
            this.lblDisplayClickNumber.Text = "Number Of click";
            // 
            // txtClickNumberToDisplay
            // 
            this.txtClickNumberToDisplay.Enabled = false;
            this.txtClickNumberToDisplay.Location = new System.Drawing.Point(949, 344);
            this.txtClickNumberToDisplay.Name = "txtClickNumberToDisplay";
            this.txtClickNumberToDisplay.Size = new System.Drawing.Size(100, 22);
            this.txtClickNumberToDisplay.TabIndex = 24;
            // 
            // mnstripDifficulty
            // 
            this.mnstripDifficulty.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.mnstripDifficulty.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.mnstripDifficulty.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mnstripDifficulty.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.difficultyToolStripMenuItem,
            this.mnstripchoiceIntermediaire,
            this.mnstripchoiceDifficile});
            this.mnstripDifficulty.Location = new System.Drawing.Point(0, 555);
            this.mnstripDifficulty.Name = "mnstripDifficulty";
            this.mnstripDifficulty.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.mnstripDifficulty.Size = new System.Drawing.Size(1094, 28);
            this.mnstripDifficulty.TabIndex = 26;
            this.mnstripDifficulty.Text = "menuStrip1";
            // 
            // difficultyToolStripMenuItem
            // 
            this.difficultyToolStripMenuItem.Name = "difficultyToolStripMenuItem";
            this.difficultyToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.difficultyToolStripMenuItem.Text = "Difficulty";
            // 
            // mnstripchoiceIntermediaire
            // 
            this.mnstripchoiceIntermediaire.Name = "mnstripchoiceIntermediaire";
            this.mnstripchoiceIntermediaire.Size = new System.Drawing.Size(112, 24);
            this.mnstripchoiceIntermediaire.Text = "Intermédiaire";
            this.mnstripchoiceIntermediaire.Click += new System.EventHandler(this.mnstripchoiceIntermediaire_Click);
            // 
            // mnstripchoiceDifficile
            // 
            this.mnstripchoiceDifficile.Name = "mnstripchoiceDifficile";
            this.mnstripchoiceDifficile.Size = new System.Drawing.Size(75, 24);
            this.mnstripchoiceDifficile.Text = "Difficile";
            this.mnstripchoiceDifficile.Click += new System.EventHandler(this.mnstripchoiceDifficile_Click);
            // 
            // errorProviderbtnStart
            // 
            this.errorProviderbtnStart.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1094, 583);
            this.Controls.Add(this.lblDisplayClickNumber);
            this.Controls.Add(this.txtClickNumberToDisplay);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.lblBesttime);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtNumberOfTry);
            this.Controls.Add(this.txtTimer);
            this.Controls.Add(this.lblNumberOfTry);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.btnStartChrono);
            this.Controls.Add(this.picboxl3e3);
            this.Controls.Add(this.picboxl0e1);
            this.Controls.Add(this.picboxl0e2);
            this.Controls.Add(this.picboxl0e3);
            this.Controls.Add(this.picboxl1e3);
            this.Controls.Add(this.picboxl1e2);
            this.Controls.Add(this.picboxl1e1);
            this.Controls.Add(this.picboxl1e0);
            this.Controls.Add(this.picboxl2e0);
            this.Controls.Add(this.picboxl2e1);
            this.Controls.Add(this.picboxl2e3);
            this.Controls.Add(this.picboxl3e2);
            this.Controls.Add(this.picboxl3e0);
            this.Controls.Add(this.picboxl3e1);
            this.Controls.Add(this.picboxl2e2);
            this.Controls.Add(this.picboxl0e0);
            this.Controls.Add(this.mnstripDifficulty);
            this.ForeColor = System.Drawing.Color.Black;
            this.MainMenuStrip = this.mnstripDifficulty;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.picboxl0e0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl2e2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl3e1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl3e0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl3e2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl2e3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl2e1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl2e0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl1e0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl1e1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl1e2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl1e3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl0e3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl0e2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl0e1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxl3e3)).EndInit();
            this.mnstripDifficulty.ResumeLayout(false);
            this.mnstripDifficulty.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderbtnStart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picboxl0e0;
        private System.Windows.Forms.PictureBox picboxl2e2;
        private System.Windows.Forms.PictureBox picboxl3e1;
        private System.Windows.Forms.PictureBox picboxl3e0;
        private System.Windows.Forms.PictureBox picboxl3e2;
        private System.Windows.Forms.PictureBox picboxl2e3;
        private System.Windows.Forms.PictureBox picboxl2e1;
        private System.Windows.Forms.PictureBox picboxl2e0;
        private System.Windows.Forms.PictureBox picboxl1e0;
        private System.Windows.Forms.PictureBox picboxl1e1;
        private System.Windows.Forms.PictureBox picboxl1e2;
        private System.Windows.Forms.PictureBox picboxl1e3;
        private System.Windows.Forms.PictureBox picboxl0e3;
        private System.Windows.Forms.PictureBox picboxl0e2;
        private System.Windows.Forms.PictureBox picboxl0e1;
        private System.Windows.Forms.PictureBox picboxl3e3;
        private System.Windows.Forms.Button btnStartChrono;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Label lblNumberOfTry;
        private System.Windows.Forms.TextBox txtTimer;
        private System.Windows.Forms.TextBox txtNumberOfTry;
        private System.Windows.Forms.Timer Chrono;
        private System.Windows.Forms.Label lblBesttime;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblDisplayClickNumber;
        private System.Windows.Forms.TextBox txtClickNumberToDisplay;
        private System.Windows.Forms.MenuStrip mnstripDifficulty;
        private System.Windows.Forms.ToolStripMenuItem mnstripchoiceDifficile;
        private System.Windows.Forms.ToolStripMenuItem mnstripchoiceIntermediaire;
        private System.Windows.Forms.ToolStripMenuItem difficultyToolStripMenuItem;
        public System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.ErrorProvider errorProviderbtnStart;
    }
}

