﻿using System;
using System.Drawing;
using System.Windows.Forms;


namespace jeu_memory
{
    class Function
    {
        Effet effet = new Effet();

        public void StartGame(Timer Chrono)
        {
            Chrono.Start();
        }

        public void RemplitTableau(PictureBox[,] arrayPicturebox, int maxLigne)
        {
            for (int ligne = 0; ligne <= maxLigne; ligne++)
            {
                for (int colonne = 0; colonne <= arrayPicturebox.GetUpperBound(1); colonne++)
                {
                    arrayPicturebox[ligne, colonne].SizeMode = PictureBoxSizeMode.StretchImage;
                    arrayPicturebox[ligne, colonne].Image = Image.FromFile(Application.StartupPath + "\\0.png");
                    arrayPicturebox[ligne, colonne].Enabled = true;

                }
            }
        }
        public void DrawImage(PictureBox[,] arrayPicturebox, int ligne, int colonne, int ligne1erclick, int colonne1erclick)
        {
            effet.effet_qui_bouge(ligne1erclick, colonne1erclick, ligne, colonne, arrayPicturebox);
            arrayPicturebox[ligne, colonne].Image = null;
            arrayPicturebox[ligne1erclick, colonne1erclick].Image = null;
            arrayPicturebox[ligne, colonne].Enabled = false;
            arrayPicturebox[ligne1erclick, colonne1erclick].Enabled = false;
        }

        public int[,] AssignationImagePictureBox(int[,] arrayImageName, int Maxligne, int Menu)
        {
            Random imageRandom = new Random();

            while (TousImagePresents3Fois(arrayImageName, Maxligne) == true) // faire une fonction while qui fait que si une image revienst trois fois il relance le truc jusqu'a qu'il y en ai 2 seulement par image
            {
                for (int ligne = 0; ligne <= Maxligne; ligne ++)
                {
                    for (int colonne = 0; colonne <= arrayImageName.GetUpperBound(1); colonne ++)
                    {
                        switch (Menu)
                        {
                            case 1:
                                arrayImageName[ligne, colonne] = imageRandom.Next(9, (arrayImageName.GetLength(0) * arrayImageName.GetLength(1) / 2 + 10));
                                break;
                            case 2:
                                arrayImageName[ligne, colonne] = imageRandom.Next(1, (arrayImageName.GetLength(0) * arrayImageName.GetLength(1) / 2 + 1));
                                break;
                        }
                    }
                }
            }
            return arrayImageName;
        }
        public Boolean TousImagePresents3Fois(int[,] arrayImageName, int Maxligne)
        {
            Boolean resultat = false;
            int nombreRegarder = arrayImageName[0, 0];

            for (int ligne = 0; ligne <= Maxligne; ligne++)
            {
                for (int colonne = 0; colonne <= arrayImageName.GetUpperBound(1); colonne++)
                {
                    nombreRegarder = arrayImageName[ligne, colonne];
                    if (TroisFois(nombreRegarder, arrayImageName, Maxligne) == false)
                    {
                        resultat = true;
                    }
                }
            }
            return resultat;
        }

        private Boolean TroisFois(int nombreRegarder, int[,] arrayImageName, int Maxligne)
        {
            int compteurNbfoisNombrevu = 0;
            for (int lignes = 0; lignes <= Maxligne; lignes++)
            {
                for (int colones = 0; colones <= arrayImageName.GetUpperBound(1); colones++)
                {
                    if (nombreRegarder == arrayImageName[lignes, colones])
                    {
                        compteurNbfoisNombrevu++;
                    }
                }
            }
            if (compteurNbfoisNombrevu == 2)
            {
                return true;
            }
            else { return false; }
        }

        public void SetRandomImage(PictureBox[,] arrayPicturebox, int[,] arrayImageName, PictureBox pictureBoxCliquer, ref int ligne, ref int colonne)
        {
            string PictureLocation = pictureBoxCliquer.Name;

            ligne = int.Parse(PictureLocation.Substring(7, 1));
            colonne = int.Parse(PictureLocation.Substring(9, 1));

            arrayPicturebox[ligne, colonne].Image = Image.FromFile(Application.StartupPath + "\\" + arrayImageName[ligne, colonne] + ".jpg");
        }

        public void TurnCardBack(PictureBox[,] arrayPicturebox, int ligne, int colonne, int ligne1erclick, int colone1erclick)
        {
            effet.attente(1000);

            arrayPicturebox[ligne, colonne].Image = Image.FromFile(Application.StartupPath + "\\0.png");
            arrayPicturebox[ligne1erclick, colone1erclick].Image = Image.FromFile(Application.StartupPath + "\\0.png");
        }
        public bool SameCard(int image1, int image2)
        {
            Boolean sameCard = false;

            if (image1 == image2)
            {
                sameCard = true;
            }
            else
            {
                sameCard = false;
            }

            return sameCard;
        }

        public void StopGame(Timer Chrono)
        {
            Chrono.Stop();
        }

        public bool AskTryagain(int clickToDisplay, double timerMinute, double timerSeconde)
        {
            string message = "Want to play again ?\n" +
                "you made it in " + clickToDisplay + " clicks, and " + String.Format("0{0} min : {1} sec", timerMinute, timerSeconde);
            string title = "Wanna try again "; 
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons);
            if (result == DialogResult.No)
            {
                EndGame();
            }
            else
            {
                
            }
            
                return false;
            
           
        }

        public void EndGame()
        {
            System.Windows.Forms.Application.Exit();
        }

        internal void StartGame(Func<PictureBox[,]> assignationImagePictureBox, Timer chrono)
        {
            throw new NotImplementedException();
        }
    }
}
